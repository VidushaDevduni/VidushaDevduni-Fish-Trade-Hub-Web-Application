<?php
include 'components/connect.php';

$query = $conn->prepare("SELECT name, email, message FROM `message` ORDER BY id DESC");
$query->execute();
$reviews = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Customer Reviews</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            outline: none;
            border: none;
            text-decoration: none;
            list-style: none;
        }

        :root {
            --space: 2rem;
            --main-color: #c4e2e0;
            --p-color: #0f5b72;
            --p-opacity: #042527;
            --white-alpha-40: rgba(5, 48, 67, 0.177);
            --white-alpha-25: rgba(6, 56, 64, 0.25);
            --backdrop-filter: blur(5px);
            --box-shadow: 2px 2px 5px rgba(175, 210, 224, 0.4);
        }

        body {
            background-color: rgb(2, 19, 31);
            color: var(--main-color);
            font-family: Arial, sans-serif;
            padding: 2rem;
        }

        .reviews {
            text-align: center;
            font-size: 2rem;
            margin-bottom: 2rem;
            color: var(--main-color);
        }

        .review-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
        }

        .review-box {
            background-color: var(--white-alpha-25);
            border: 2px solid var(--white-alpha-40);
            backdrop-filter: var(--backdrop-filter);
            box-shadow: var(--box-shadow);
            padding: 1.5rem;
            border-radius: .5rem;
            color: #fff;
        }

        .review-box h3 {
            margin-bottom: 0.5rem;
            font-size: 1.5rem;
            color: var(--main-color);
        }

        .review-box p {
            font-size: 1rem;
            margin: 0.3rem 0;
        }

        .empty {
            text-align: center;
            background-color: var(--white-alpha-25);
            border: 2px solid var(--white-alpha-40);
            backdrop-filter: var(--backdrop-filter);
            box-shadow: var(--box-shadow);
            padding: 2rem;
            border-radius: .5rem;
            color: var(--main-color);
        }
    </style>
</head>
<body>

    <h1><p class="reviews">Customer Reviews</p></h1>

    <div class="review-container">
        <?php if (!empty($reviews)): ?>
            <?php foreach ($reviews as $review): ?>
                <div class="review-box">
                    <h3><?php echo htmlspecialchars($review['name']); ?></h3>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($review['email']); ?></p>
                    <p><?php echo htmlspecialchars($review['message']); ?></p>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty">
                <p>No customer reviews available.</p>
            </div>
        <?php endif; ?>
    </div>

</body>
</html>
