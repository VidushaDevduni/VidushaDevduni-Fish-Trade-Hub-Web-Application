<?php

if (isset($_POST['add_to_cart'])) {
    if ($user_id != '') {
        // Check if 'product_id' is set in the POST request
        if (isset($_POST['product_id'])) {
            $id = unique_id();
            $product_id = $_POST['product_id'];  // Ensure product_id is set here

            // Sanitize and validate qty
            $qty = $_POST['qty'];
            $qty = filter_var($qty, FILTER_SANITIZE_STRING);

            // Verify if the product already exists in the cart for the user
            $verify_cart = $conn->prepare("SELECT * FROM cart WHERE user_id = ? AND product_id = ?");
            $verify_cart->execute([$user_id, $product_id]);

            // Check if the cart has more than 20 items
            $max_cart_items = $conn->prepare("SELECT * FROM cart WHERE user_id = ?");
            $max_cart_items->execute([$user_id]);

            if ($verify_cart->rowCount() > 0) {
                $warning_msg[] = 'Product already exists in your cart';
            } else if ($max_cart_items->rowCount() > 20) {
                $warning_msg[] = 'Your cart is full';
            } else {
                // Retrieve product price details
                $select_price = $conn->prepare("SELECT * FROM products WHERE id = ? LIMIT 1");
                $select_price->execute([$product_id]);
                $fetch_price = $select_price->fetch(PDO::FETCH_ASSOC);

                if ($fetch_price) {
                    // Insert the product into the cart
                    $insert_cart = $conn->prepare("INSERT INTO cart(id, user_id, product_id, price, qty) VALUES(?,?,?,?,?)");
                    $insert_cart->execute([$id, $user_id, $product_id, $fetch_price['price'], $qty]);
                    $success_msg[] = 'Product added to cart successfully';

                    // Redirect to cart page after adding the product
                    header('Location: cart.php');
                    exit();
                } else {
                    $warning_msg[] = 'Product not found';
                }
            }
        } else {
            $warning_msg[] = 'Product ID is missing';
        }
    } else {
        $warning_msg[] = 'Please login first';
    }
}

?>