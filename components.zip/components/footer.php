<div class="newsletter">
    <div class="content">
        <span>Get latest Fish trade hub updates</span>
        <h1>Subscribe our newsletter</h1>
        
        <div class="input-field">
            <input type="email" name="" placeholder="Enter your email">
            <button class="btn">Subscribe</button>
        </div>
        <p>No ads, No trails, NO commitment</p>
        <div class="box-container">
            <div class="box"> 
                <div class="box-counter"><p class="counter">50000</p><i class="bx bx-plus"></i></div>
                <h3>successfully Trained</h3>
                <p>Learners & counting</p>
            </div>
            <div class="box"> 
                <div class="box-counter"><p class="counter">10000</p><i class="bx bx-plus"></i></div>
                <h3>Certification Seller</h3>
                <p class="counter">online seller</p>
            </div>
        </div>
    </div>
</div>