
document.addEventListener('DOMContentLoaded', function () {
    const userBtn = document.querySelector('#user-btn');
    const searchBtn = document.querySelector('#search-btn');
    const menuBtn = document.querySelector('#menu-btn');

    if (userBtn) {
        userBtn.addEventListener('click', function () {
            const profile = document.querySelector('.header .flex .profile-detail');
            const searchForm = document.querySelector('.header .flex .search-form');
            if (profile && searchForm) {
                profile.classList.toggle('active');
                searchForm.classList.remove('active');
            }
        });
    }

    if (searchBtn) {
        searchBtn.addEventListener('click', function () {
            const searchForm = document.querySelector('.header .flex .search-form');
            const profile = document.querySelector('.header .flex .profile-detail');
            if (searchForm && profile) {
                searchForm.classList.toggle('active');
                profile.classList.remove('active');
            }
        });
    }

    if (menuBtn) {
        menuBtn.addEventListener('click', function () {
            const navbar = document.querySelector('.navbar');
            if (navbar) {
                navbar.classList.toggle('active');
            }
        });
    }
});


