<?php

include '../components/connect.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';
require '../PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (isset($_COOKIE['seller_id'])) {
    $seller_id = $_COOKIE['seller_id'];
} else {
    $seller_id = '';
    header('location:login.php');
}

if (isset($_POST['delete'])) {
    $p_id = filter_var($_POST['product_id'], FILTER_SANITIZE_STRING);

    // Get product details before deletion
    $get_product = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $get_product->execute([$p_id]);
    $product = $get_product->fetch(PDO::FETCH_ASSOC);

    // Delete product
    $delete_product = $conn->prepare("DELETE FROM `products` WHERE id = ?");
    $delete_product->execute([$p_id]);

    $success_msg[] = 'Product deleted successfully';

    // Send email to all users
    $get_users = $conn->prepare("SELECT email FROM users");
    $get_users->execute();
    $users = $get_users->fetchAll(PDO::FETCH_ASSOC);

    $get_seller_email = $conn->prepare("SELECT email FROM sellers WHERE id = ?");
    $get_seller_email->execute([$seller_id]);
    $seller = $get_seller_email->fetch(PDO::FETCH_ASSOC);
    $from_email = $seller['email'];

    foreach ($users as $user) {
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'vidushadevduni@gmail.com';
            $mail->Password = 'rryy bujh dxyx nciz';
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            $mail->setFrom($from_email, 'Fish Seller');
            $mail->addAddress($user['email']);
            $mail->isHTML(true);
            $mail->Subject = "Fish Product Removed!";
            $mail->Body = "
                <h3>A fish product has been removed</h3>
                <p><strong>Type:</strong> {$product['fish_type']}</p>
                <p><strong>Arrival Place:</strong> {$product['arrival_place']}</p>
                <p><strong>Note:</strong> This product is no longer available.</p>
            ";
            $mail->send();
        } catch (Exception $e) {
            error_log("Delete Email to {$user['email']} failed: {$mail->ErrorInfo}");
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fish Trade Products Page</title>
    <link rel="stylesheet" type="text/css" href="../css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
</head>
<body>

<div class="main-container">
    <?php include '../components/admin_header.php'; ?>
    <section class="show-post">
        <div class="heading">
            <h1>Your Products</h1>
            <img src="../image/fish1.png">
        </div>

        <div class="box-container">
            <?php
            $select_products = $conn->prepare("SELECT * FROM `products` WHERE seller_id = ?");
            $select_products->execute([$seller_id]);
            if ($select_products->rowCount() > 0) {
                while ($fetch_products = $select_products->fetch(PDO::FETCH_ASSOC)) {
            ?>
            <form action="" method="post" class="box">
                <input type="hidden" name="product_id" value="<?= $fetch_products['id']; ?>">
                <?php if ($fetch_products['image'] != '') { ?>
                    <img src="../uploaded_files/<?= $fetch_products['image']; ?>" class="image">
                <?php } ?>
                <div class="status" style="color: <?= ($fetch_products['status'] == 'active') ? 'limegreen' : 'coral'; ?>">
                    <?= $fetch_products['status']; ?>
                </div>
                <div class="price">Rs. <?= $fetch_products['price']; ?></div>

                <div class="content">
                    <div class="title"><?= $fetch_products['fish_type']; ?></div>
                    <div class="details">
                        <div class="info-box">Weight: <?= $fetch_products['fish_weight']; ?> kg</div>
                        <p>Arrival Time: <?= $fetch_products['arrival_time']; ?></p>
                        <p>Arrival Place: <?= $fetch_products['arrival_place']; ?></p>
                    </div>
                    <div class="flex-btn">
                        <a href="edit_product.php?id=<?= $fetch_products['id']; ?>" class="btn">Edit</a>
                        <button type="submit" name="delete" class="btn" onclick="return confirm('Delete this product?');">Delete</button>
                        <a href="read_product.php?post_id=<?= $fetch_products['id']; ?>" class="btn">Read</a>
                    </div>
                </div>
            </form>
            <?php
                }
            } else {
                echo '
                <div class="empty">
                    <p>No product added yet!<br> 
                    <a href="admin_fishproduct.php" class="btn" style="margin-top:1.5rem;">Add Fish Products</a></p>
                </div>';
            }
            ?>
        </div>
    </section>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script> 
<script src="../js/admin_script.js"></script> 
<?php include '../components/alert.php'; ?>
</body>
</html>
