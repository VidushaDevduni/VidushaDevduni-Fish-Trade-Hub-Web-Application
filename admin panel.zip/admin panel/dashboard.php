<?php

    include '../components/connect.php';

   if(isset($_COOKIE['seller_id'])){
        $seller_id = $_COOKIE['seller_id'];

   }else{
    $seller_id = '';
    header('location:login.php');
   }

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>dashboard</title>
    <link rel="stylesheet" type="text/css" href="../css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

    <style>
         .box-container {
        background-color:rgb(96, 122, 121);
        padding: 20px;
        border-radius: 10px;
    }
    .heading h1 {
        color: white;
    }
    
    </style>

</head>
<body>

<div class="main-container">
    <?php include '../components/admin_header.php'; ?>
    <section class="dashboard">
    <div class="heading">
        <h1>dashboard</h1>
        <img src="../image/fish1.png">
       

    </div>
    <div class="box-container"> 

        <div class="box">
            
            <p><?= $fetch_profile['name'];?></p>
            <a href="update.php" class="btn">update profile</a>
        </div>
       
        <div class="box">
            <?php
                $select_products = $conn->prepare("SELECT * FROM `products` WHERE seller_id=?");
                $select_products-> execute([$seller_id]);
                $number_of_products = $select_products->rowCount();
            ?>
           
            <p>products added</p>
            <a href="admin_fishproduct.php" class="btn">add fish products</a>
        </div>
        <div class="box">
            <?php
                $select_active_products = $conn->prepare("SELECT * FROM `products` WHERE seller_id=? AND status = ?");
                $select_active_products-> execute([$seller_id, 'active']);
                $number_of_active_products = $select_active_products->rowCount();
            ?>
         
            <p>total active products</p>
            <a href="view_product.php" class="btn">active products</a>
        </div>
       
        
        <div class="box">
    <?php
        // Fetch latest orders from customer_orders table
        $select_orders = $conn->prepare("SELECT * FROM `customer_orders` ORDER BY placed_on DESC LIMIT 5");
        $select_orders->execute();
        $orders = $select_orders->fetchAll(PDO::FETCH_ASSOC);
    ?>
    <h3><?= count($orders); ?></h3>
    <p>Customer Orders</p>
    <a href="view_orders.php" class="btn">View Orders</a>
</div>

        <div class="box">
            <?php
                $select_sellers = $conn->prepare("SELECT * FROM `sellers` ");
                $select_sellers->execute();
                $number_of_sellers = $select_sellers-> rowCount();
            ?>
            
            <p>customers message</p>
            <a href="admin_message.php" class="btn">See customers message</a>
       
      
      
    </div>
</section>

</div>
    

<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script> 
<script src="../js/admin_script.js"> </script> 

<?php  include '../components/alert.php'; ?>
    
</body>
</html>