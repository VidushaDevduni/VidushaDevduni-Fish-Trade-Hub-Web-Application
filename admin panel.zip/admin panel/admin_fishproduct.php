<?php

include '../components/connect.php';

require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';
require '../PHPMailer/src/Exception.php';


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;



include '../components/connect.php';

if (isset($_COOKIE['seller_id'])) {
    $seller_id = $_COOKIE['seller_id'];
} else {
    $seller_id = '';
    header('location:login.php');
}

if (isset($_POST['publish'])) {
    $id = unique_id();
    $fish_type = $_POST['fish_type'];
    $fish_type = filter_var($fish_type, FILTER_SANITIZE_STRING);
    $fish_weight = $_POST['fish_weight'];
    $fish_weight = filter_var($fish_weight, FILTER_SANITIZE_STRING);
    $arrival_time = $_POST['arrival_time'];
    $arrival_time = filter_var($arrival_time, FILTER_SANITIZE_STRING);
    $arrival_place = $_POST['arrival_place'];
    $arrival_place = filter_var($arrival_place, FILTER_SANITIZE_STRING);
    $price = $_POST['price'];
    $price = filter_var($price, FILTER_SANITIZE_STRING);
    $details = $_POST['details'];
    $details = filter_var($details, FILTER_SANITIZE_STRING);
    $status = 'active';

    $image = $_FILES['image']['name'];
    $image = filter_var($image, FILTER_SANITIZE_STRING);
    $image_size = $_FILES['image']['size'];
    $image_tmp_name = $_FILES['image']['tmp_name'];
    $image_folder = '../uploaded_files/' . $image;

    $select_image = $conn->prepare("SELECT * FROM products WHERE image = ? AND seller_id = ?");
    $select_image->execute([$image, $seller_id]);

    if (isset($image)) {
        if ($select_image->rowCount() > 0) {
            $warning_msg[] = "Image name repeated";
        } elseif ($image_size > 2000000) {
            $warning_msg[] = 'Image size is too large';
        } else {
            move_uploaded_file($image_tmp_name, $image_folder);
        }
    } else {
        $image = '';
    }

    if ($select_image->rowCount() > 0 && $image != '') {
        $warning_msg[] = 'Please rename your image';
    } else {
        $insert_product = $conn->prepare("INSERT INTO products (id, seller_id, fish_type, fish_weight, arrival_time, arrival_place, price, details, image, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");

        $insert_product->execute([$id, $seller_id, $fish_type, $fish_weight, $arrival_time, $arrival_place, $price, $details, $image, $status]);
        
        // Fetch all registered customers
$get_users = $conn->prepare("SELECT email FROM users");
$get_users->execute();
$users = $get_users->fetchAll(PDO::FETCH_ASSOC);

// Get seller email for 'From'
$get_seller_email = $conn->prepare("SELECT email FROM sellers WHERE id = ?");
$get_seller_email->execute([$seller_id]);
$seller = $get_seller_email->fetch(PDO::FETCH_ASSOC);
$from_email = $seller['email'];

// Loop through each customer and send email
foreach ($users as $user) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'vidushadevduni@gmail.com';       // your Gmail
        $mail->Password = 'rryy bujh dxyx nciz';          // app password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom($from_email, 'Fish Seller');
        $mail->addAddress($user['email']);

        $mail->isHTML(true);
        $mail->Subject = "New Fish Product Available!";
        $mail->Body = "
            <h3>New Fish Added!</h3>
            <p><strong>Type:</strong> $fish_type</p>
            <p><strong>Weight:</strong> $fish_weight kg</p>
            <p><strong>Arrival Time:</strong> $arrival_time</p>
            <p><strong>Place:</strong> $arrival_place</p>
            <p><strong>Price:</strong> Rs. $price</p>
            <p><strong>Details:</strong> $details</p>
        ";

        $mail->send();
    } catch (Exception $e) {
        error_log("Email to {$user['email']} failed: {$mail->ErrorInfo}");
    }
}


        $success_msg[] = 'Product inserted successfully';

        
        
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fish Trade Hub - show fish product page</title>
    <link rel="stylesheet" type="text/css" href="../css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
</head>
<body>
<div class="main-container">
    <?php include '../components/admin_header.php'; ?>
    <section class="post-editor">
        <div class="heading">
            <h1 style="color: white;">Add Product</h1>
            <img src="../image/fish1.png">
        </div>
        <div class="form-container">
            <form action="" method="post" enctype="multipart/form-data" class="register">
                <div class="input-field">
                    <p>Fish Type</p>
                    <input type="text" name="fish_type" maxlength="100" placeholder="Add fish type" required class="box">
                </div>
                <div class="input-field">
                    <p>Fish Weight (kg)</p>
                    <input type="number" name="fish_weight" maxlength="10" min="0" max="9999999999" placeholder="Add fish weight" required class="box">
                </div>
                <div class="input-field">
                    <p>Arrival Time</p>
                    <input type="datetime-local" name="arrival_time" placeholder="Add arrival time" required class="box">
                </div>
                <div class="input-field">
                    <p>Arrival Place</p>
                    <input type="text" name="arrival_place" maxlength="100" placeholder="Add arrival place" required class="box">
                </div>
                <div class="input-field">
                    <p>Price(for 1kg)</p>
                    <input type="text" name="price" maxlength="10" placeholder="Add price" required class="box">
                </div>
                <div class="input-field">
                    <p>Fish Details</p>
                    <textarea name="details" placeholder="Add product detail" required maxlength="1000" class="box"></textarea>
                </div>
                <div class="input-field">
                    <p>Product Image</p>
                    <input type="file" name="image" accept="image/*" required class="box">
                </div>
                <div class="flex-btn">
                    <input type="submit" name="publish" value="Add Fish Product" class="btn">
                    <input type="submit" name="draft" value="Save as Draft" class="btn">
                </div>
              
            </form>
            <a href="../admin panel/fisherman.html" class="btn">Add location</a>
        </div>
    </section>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
<script src="../js/admin_script.js"></script>
<?php include '../components/alert.php'; ?>
</body>
</html>