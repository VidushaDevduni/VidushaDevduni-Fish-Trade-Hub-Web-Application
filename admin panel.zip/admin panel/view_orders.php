<?php
include '../components/connect.php';

// Auto delete orders older than 3 days
$delete_old_orders = $conn->prepare("DELETE FROM `customer_orders` WHERE placed_on < NOW() - INTERVAL 3 DAY");
$delete_old_orders->execute();

if (!isset($_COOKIE['seller_id'])) {
    header('location:login.php');
    exit;
}

// Delete logic via GET request
if (isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    $delete_order = $conn->prepare("DELETE FROM `customer_orders` WHERE id = ?");
    $delete_order->execute([$delete_id]);
    header('location:customer_orders.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Customer Orders</title>
    <link rel="stylesheet" href="../css/detailsadmin_style.css">
    <style>
        .btn-back, .btn-delete {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 15px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .btn-delete {
            background-color: #e74c3c;
        }

        .btn-back:hover {
            background-color: #3e8e41;
        }

        .btn-delete:hover {
            background-color: #c0392b;
        }

        .back-btn-container {
            text-align: center;
            margin-top: 30px;
        }
    </style>
</head>
<body>

<section class="orders">
    <h1 class="heading">Customer Orders</h1>
    <div class="box-container">
        <?php
        $select_orders = $conn->prepare("SELECT * FROM `customer_orders` ORDER BY placed_on DESC");
        $select_orders->execute();

        if ($select_orders->rowCount() > 0) {
            while ($row = $select_orders->fetch(PDO::FETCH_ASSOC)) {
                echo '
                <div class="box">
                    <p><strong>Name:</strong> ' . $row['name'] . '</p>
                    <p><strong>Number:</strong> ' . $row['number'] . '</p>
                    <p><strong>Email:</strong> ' . $row['email'] . '</p>
                    <p><strong>Method:</strong> ' . $row['method'] . '</p>
                    <p><strong>Address:</strong> ' . $row['flat'] . ', ' . $row['street'] . ', ' . $row['city'] . '</p>
                    <p><strong>Country:</strong> ' . $row['country'] . '</p>
                    <p><strong>Pin:</strong> ' . $row['pin'] . '</p>
                    <p><strong>Total:</strong> Rs.' . $row['total_price'] . '</p>
                    <p><strong>Placed on:</strong> ' . $row['placed_on'] . '</p>
                </div>';
            }
        } else {
            echo '<p class="empty">No orders placed yet!</p>';
        }
        ?>
    </div>

    <div class="back-btn-container">
        <a href="dashboard.php" class="btn-back">← Back to Dashboard</a>
    </div>
</section>

</body>
</html>
