<?php
include '../components/connect.php';

try {
    $stmt = $conn->prepare("DELETE FROM products WHERE created_at <= NOW() - INTERVAL 2 HOUR");
    $stmt->execute();
    echo "Products older than 2 hours deleted successfully.";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
