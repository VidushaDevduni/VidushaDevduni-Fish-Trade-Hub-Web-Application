<?php
include '../components/connect.php';

require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';
require '../PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (isset($_COOKIE['seller_id'])) {
    $seller_id = $_COOKIE['seller_id'];
} else {
    $seller_id = '';
    header('location:login.php');
}

if (isset($_POST['update'])) {
    $product_id = filter_var($_POST['product_id'], FILTER_SANITIZE_STRING);
    $fish_type = filter_var($_POST['fish_type'], FILTER_SANITIZE_STRING);
    $fish_weight = filter_var($_POST['fish_weight'], FILTER_SANITIZE_STRING);
    $arrival_time = filter_var($_POST['arrival_time'], FILTER_SANITIZE_STRING);
    $arrival_place = filter_var($_POST['arrival_place'], FILTER_SANITIZE_STRING);
    $price = filter_var($_POST['price'], FILTER_SANITIZE_STRING);
    $details = filter_var($_POST['details'], FILTER_SANITIZE_STRING);
    $status = filter_var($_POST['status'], FILTER_SANITIZE_STRING);

    $old_image = $_POST['old_image'];
    $image = $_FILES['image']['name'];
    $image = filter_var($image, FILTER_SANITIZE_STRING);
    $image_size = $_FILES['image']['size'];
    $image_tmp_name = $_FILES['image']['tmp_name'];
    $image_folder = '../uploaded_files/' . $image;

    $update_product = $conn->prepare("UPDATE products SET fish_type = ?, fish_weight = ?, arrival_time = ?, arrival_place = ?, price = ?, details = ?, status = ? WHERE id = ? AND seller_id = ?");
    $update_product->execute([$fish_type, $fish_weight, $arrival_time, $arrival_place, $price, $details, $status, $product_id, $seller_id]);

    $success_msg[] = 'Product updated successfully';

    if (!empty($image)) {
        if ($image_size > 2000000) {
            $warning_msg[] = 'Image size is too large';
        } else {
            $select_image = $conn->prepare("SELECT * FROM products WHERE image = ? AND seller_id = ?");
            $select_image->execute([$image, $seller_id]);

            if ($select_image->rowCount() > 0) {
                $warning_msg[] = 'Please rename your image to avoid conflicts';
            } else {
                move_uploaded_file($image_tmp_name, $image_folder);

                $update_image = $conn->prepare("UPDATE products SET image = ? WHERE id = ? AND seller_id = ?");
                $update_image->execute([$image, $product_id, $seller_id]);

                if ($old_image != $image && $old_image != '') {
                    unlink('../uploaded_files/' . $old_image);
                }

                $success_msg[] = 'Image updated successfully!';
            }
        }
    }

    // Send email notifications
    $get_users = $conn->prepare("SELECT email FROM users");
    $get_users->execute();
    $users = $get_users->fetchAll(PDO::FETCH_ASSOC);

    $get_seller_email = $conn->prepare("SELECT email FROM sellers WHERE id = ?");
    $get_seller_email->execute([$seller_id]);
    $seller = $get_seller_email->fetch(PDO::FETCH_ASSOC);
    $from_email = $seller['email'];

    foreach ($users as $user) {
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'vidushadevduni@gmail.com';  // Gmail address
            $mail->Password = 'rryy bujh dxyx nciz';        // App password
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            $mail->setFrom($from_email, 'Fish Seller');
            $mail->addAddress($user['email']);

            $mail->isHTML(true);
            $mail->Subject = "Fish Product Updated!";
            $mail->Body = "
                <h3>Fish Product Updated!</h3>
                <p><strong>Type:</strong> $fish_type</p>
                <p><strong>Weight:</strong> $fish_weight kg</p>
                <p><strong>Arrival Time:</strong> $arrival_time</p>
                <p><strong>Place:</strong> $arrival_place</p>
                <p><strong>Price:</strong> Rs. $price</p>
                <p><strong>Details:</strong> $details</p>
                <p><strong>Status:</strong> $status</p>
            ";

            $mail->send();
        } catch (Exception $e) {
            error_log("Email to {$user['email']} failed: {$mail->ErrorInfo}");
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <link rel="stylesheet" type="text/css" href="../css/admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
</head>
<body>
<div class="main-container">
    <?php include '../components/admin_header.php'; ?>
    <section class="post-editor">
        <div class="heading">
            <h1 style="color: white;">Edit Product</h1>
            <img src="../image/fish1.png">
        </div>
        <div class="box-container">
            <?php
            $product_id = $_GET['id'];
            $select_product = $conn->prepare("SELECT * FROM products WHERE id = ? AND seller_id = ?");
            $select_product->execute([$product_id, $seller_id]);

            if ($select_product->rowCount() > 0) {
                while ($fetch_product = $select_product->fetch(PDO::FETCH_ASSOC)) {
            ?>
            <div class="form-container">
                <form action="" method="post" enctype="multipart/form-data" class="register">
                    <input type="hidden" name="old_image" value="<?= $fetch_product['image']; ?>">
                    <input type="hidden" name="product_id" value="<?= $fetch_product['id']; ?>">
                    <div class="input-field">
                        <p>Product Status</p>
                        <select name="status" class="box">
                            <option value="<?= $fetch_product['status']; ?>"><?= ucfirst($fetch_product['status']); ?></option>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                    <div class="input-field">
                        <p>Fish Type</p>
                        <input type="text" name="fish_type" value="<?= $fetch_product['fish_type']; ?>" required class="box">
                    </div>
                    <div class="input-field">
                        <p>Fish Weight (kg)</p>
                        <input type="number" name="fish_weight" value="<?= $fetch_product['fish_weight']; ?>" min="0" max="9999999999" required class="box">
                    </div>
                    <div class="input-field">
                        <p>Arrival Time</p>
                        <input type="datetime-local" name="arrival_time" value="<?= $fetch_product['arrival_time']; ?>" required class="box">
                    </div>
                    <div class="input-field">
                        <p>Arrival Place</p>
                        <input type="text" name="arrival_place" value="<?= $fetch_product['arrival_place']; ?>" required class="box">
                    </div>
                    <div class="input-field">
                        <p>Price</p>
                        <input type="text" name="price" value="<?= $fetch_product['price']; ?>" required class="box">
                    </div>
                    <div class="input-field">
                        <p>Fish Details</p>
                        <textarea name="details" required class="box"><?= $fetch_product['details']; ?></textarea>
                    </div>
                    <div class="input-field">
                        <p>Product Image</p>
                        <input type="file" name="image" accept="image/*" class="box">
                        <img src="../uploaded_files/<?= $fetch_product['image']; ?>" alt="Current Image" width="150">
                    </div>
                    <div class="flex-btn">
                        <input type="submit" name="update" value="Update Product" class="btn">
                    </div>
                </form>
            </div>
            <?php
                }
            } else {
                echo '<p class="empty">No product found!</p>';
            }
            ?>
        </div>
    </section>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
<script src="../js/admin_script.js"></script>
<?php include '../components/alert.php'; ?>
</body>
</html>
